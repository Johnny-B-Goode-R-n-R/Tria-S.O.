﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ChB_Laptop = New System.Windows.Forms.CheckBox()
        Me.ChB_SSD = New System.Windows.Forms.CheckBox()
        Me.ChB_OnlyWin = New System.Windows.Forms.CheckBox()
        Me.ChB_OnlyFREE_OS = New System.Windows.Forms.CheckBox()
        Me.ChB_Embeded_GPU = New System.Windows.Forms.CheckBox()
        Me.ChB_CPU_x64 = New System.Windows.Forms.CheckBox()
        Me.ChB_CPU_Multi_Core = New System.Windows.Forms.CheckBox()
        Me.ChB_NO_internet = New System.Windows.Forms.CheckBox()
        Me.ChB_Wifi = New System.Windows.Forms.CheckBox()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Lbl_Paquets = New System.Windows.Forms.Label()
        Me.RB_Linux_Others = New System.Windows.Forms.RadioButton()
        Me.RB_Linux_RPM = New System.Windows.Forms.RadioButton()
        Me.RB_Linux_DEB = New System.Windows.Forms.RadioButton()
        Me.ChLB_Linux_Type = New System.Windows.Forms.CheckedListBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.NumericUpDownCPU_Hz = New System.Windows.Forms.NumericUpDown()
        Me.ChB_Mhz = New System.Windows.Forms.CheckBox()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Lbl_RAM = New System.Windows.Forms.Label()
        Me.NumericUpDownRAM = New System.Windows.Forms.NumericUpDown()
        Me.ChB_RAM_MB = New System.Windows.Forms.CheckBox()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.Lbl_GPU = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Lbl_GPU_RAM = New System.Windows.Forms.Label()
        Me.NumericUpDown_GPU_MB_RAM = New System.Windows.Forms.NumericUpDown()
        Me.RB_other_GPUs = New System.Windows.Forms.RadioButton()
        Me.RB_intel = New System.Windows.Forms.RadioButton()
        Me.RB_AMD_ATI = New System.Windows.Forms.RadioButton()
        Me.RB_nVidia = New System.Windows.Forms.RadioButton()
        Me.ChLB_GPU_Brand = New System.Windows.Forms.CheckedListBox()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.Lbl_HDD_GB_info = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Lbl_HDD = New System.Windows.Forms.Label()
        Me.NumericUpDownHDD_GB = New System.Windows.Forms.NumericUpDown()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Bt_reset = New System.Windows.Forms.Button()
        Me.LinkWindows = New System.Windows.Forms.LinkLabel()
        Me.LinkLinux = New System.Windows.Forms.LinkLabel()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.RB_Lang_FRA = New System.Windows.Forms.RadioButton()
        Me.RB_Lang_ESP = New System.Windows.Forms.RadioButton()
        Me.RB_Lang_ENG = New System.Windows.Forms.RadioButton()
        Me.RB_Lang_CAT = New System.Windows.Forms.RadioButton()
        Me.Lbl_hack = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Lbl_CPU_Name = New System.Windows.Forms.Label()
        Me.TB_CPU_Name = New System.Windows.Forms.TextBox()
        Me.TB_PC_HDD = New System.Windows.Forms.TextBox()
        Me.TB_PC_GPU = New System.Windows.Forms.TextBox()
        Me.TB_PC_RAM = New System.Windows.Forms.TextBox()
        Me.TB_PC_CPU = New System.Windows.Forms.TextBox()
        Me.Lbl_PC_HDD = New System.Windows.Forms.Label()
        Me.Lbl_PC_GPU = New System.Windows.Forms.Label()
        Me.Lbl_PC_RAM = New System.Windows.Forms.Label()
        Me.Lbl_PC_CPU = New System.Windows.Forms.Label()
        Me.Bt_PC = New System.Windows.Forms.Button()
        Me.RTB_dxdiag = New System.Windows.Forms.RichTextBox()
        Me.Bt_Credits = New System.Windows.Forms.Button()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        CType(Me.NumericUpDownCPU_Hz, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        CType(Me.NumericUpDownRAM, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage4.SuspendLayout()
        CType(Me.NumericUpDown_GPU_MB_RAM, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage5.SuspendLayout()
        CType(Me.NumericUpDownHDD_GB, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(22, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(676, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Tria Sistema Operatiu - versió 1.2 (c) 2020 by Joan Baptista ALIES Johnny B. R'n'" &
    "R"
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(0, 47)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(1007, 18)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Aquesta aplicació t'ajudarà a triar els millors Sistemes Operatius per a cada ord" &
    "inador, indicant només les característiques bàsiques del PC"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ChB_Laptop
        '
        Me.ChB_Laptop.AutoSize = True
        Me.ChB_Laptop.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChB_Laptop.Location = New System.Drawing.Point(16, 6)
        Me.ChB_Laptop.Name = "ChB_Laptop"
        Me.ChB_Laptop.Size = New System.Drawing.Size(141, 22)
        Me.ChB_Laptop.TabIndex = 2
        Me.ChB_Laptop.Text = "Ordinador portàtil"
        Me.ChB_Laptop.UseVisualStyleBackColor = True
        '
        'ChB_SSD
        '
        Me.ChB_SSD.AutoSize = True
        Me.ChB_SSD.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChB_SSD.Location = New System.Drawing.Point(12, 21)
        Me.ChB_SSD.Name = "ChB_SSD"
        Me.ChB_SSD.Size = New System.Drawing.Size(159, 22)
        Me.ChB_SSD.TabIndex = 3
        Me.ChB_SSD.Text = "Disc dur SSD o M.2"
        Me.ChB_SSD.UseVisualStyleBackColor = True
        '
        'ChB_OnlyWin
        '
        Me.ChB_OnlyWin.AutoSize = True
        Me.ChB_OnlyWin.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChB_OnlyWin.Location = New System.Drawing.Point(331, 6)
        Me.ChB_OnlyWin.Name = "ChB_OnlyWin"
        Me.ChB_OnlyWin.Size = New System.Drawing.Size(290, 22)
        Me.ChB_OnlyWin.TabIndex = 4
        Me.ChB_OnlyWin.Text = "Sistemes Operatius Microsoft Windows"
        Me.ChB_OnlyWin.UseVisualStyleBackColor = True
        '
        'ChB_OnlyFREE_OS
        '
        Me.ChB_OnlyFREE_OS.AutoSize = True
        Me.ChB_OnlyFREE_OS.Checked = True
        Me.ChB_OnlyFREE_OS.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ChB_OnlyFREE_OS.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChB_OnlyFREE_OS.Location = New System.Drawing.Point(331, 47)
        Me.ChB_OnlyFREE_OS.Name = "ChB_OnlyFREE_OS"
        Me.ChB_OnlyFREE_OS.Size = New System.Drawing.Size(233, 22)
        Me.ChB_OnlyFREE_OS.TabIndex = 5
        Me.ChB_OnlyFREE_OS.Text = "Sistemes Operatius GNU/Linux"
        Me.ChB_OnlyFREE_OS.UseVisualStyleBackColor = True
        '
        'ChB_Embeded_GPU
        '
        Me.ChB_Embeded_GPU.AutoSize = True
        Me.ChB_Embeded_GPU.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChB_Embeded_GPU.Location = New System.Drawing.Point(3, 23)
        Me.ChB_Embeded_GPU.Name = "ChB_Embeded_GPU"
        Me.ChB_Embeded_GPU.Size = New System.Drawing.Size(340, 22)
        Me.ChB_Embeded_GPU.TabIndex = 6
        Me.ChB_Embeded_GPU.Text = "Targeta gràfica integrada (memòria compartida)"
        Me.ChB_Embeded_GPU.UseVisualStyleBackColor = True
        '
        'ChB_CPU_x64
        '
        Me.ChB_CPU_x64.AutoSize = True
        Me.ChB_CPU_x64.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChB_CPU_x64.Location = New System.Drawing.Point(6, 24)
        Me.ChB_CPU_x64.Name = "ChB_CPU_x64"
        Me.ChB_CPU_x64.Size = New System.Drawing.Size(180, 22)
        Me.ChB_CPU_x64.TabIndex = 7
        Me.ChB_CPU_x64.Text = "Processador de 64 bits"
        Me.ChB_CPU_x64.UseVisualStyleBackColor = True
        '
        'ChB_CPU_Multi_Core
        '
        Me.ChB_CPU_Multi_Core.AutoSize = True
        Me.ChB_CPU_Multi_Core.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChB_CPU_Multi_Core.Location = New System.Drawing.Point(331, 24)
        Me.ChB_CPU_Multi_Core.Name = "ChB_CPU_Multi_Core"
        Me.ChB_CPU_Multi_Core.Size = New System.Drawing.Size(250, 22)
        Me.ChB_CPU_Multi_Core.TabIndex = 8
        Me.ChB_CPU_Multi_Core.Text = "Processador amb 2 o MES nuclis"
        Me.ChB_CPU_Multi_Core.UseVisualStyleBackColor = True
        '
        'ChB_NO_internet
        '
        Me.ChB_NO_internet.AutoSize = True
        Me.ChB_NO_internet.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChB_NO_internet.Location = New System.Drawing.Point(16, 47)
        Me.ChB_NO_internet.Name = "ChB_NO_internet"
        Me.ChB_NO_internet.Size = New System.Drawing.Size(253, 22)
        Me.ChB_NO_internet.TabIndex = 9
        Me.ChB_NO_internet.Text = "Ordinador NO connectat a internet"
        Me.ChB_NO_internet.UseVisualStyleBackColor = True
        '
        'ChB_Wifi
        '
        Me.ChB_Wifi.AutoSize = True
        Me.ChB_Wifi.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChB_Wifi.Location = New System.Drawing.Point(16, 102)
        Me.ChB_Wifi.Name = "ChB_Wifi"
        Me.ChB_Wifi.Size = New System.Drawing.Size(291, 22)
        Me.ChB_Wifi.TabIndex = 10
        Me.ChB_Wifi.Text = "Ordinador connectat a internet, via Wi-Fi"
        Me.ChB_Wifi.UseVisualStyleBackColor = True
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(26, 141)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(700, 193)
        Me.TabControl1.TabIndex = 11
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.Lbl_Paquets)
        Me.TabPage1.Controls.Add(Me.RB_Linux_Others)
        Me.TabPage1.Controls.Add(Me.RB_Linux_RPM)
        Me.TabPage1.Controls.Add(Me.RB_Linux_DEB)
        Me.TabPage1.Controls.Add(Me.ChLB_Linux_Type)
        Me.TabPage1.Controls.Add(Me.ChB_Laptop)
        Me.TabPage1.Controls.Add(Me.ChB_Wifi)
        Me.TabPage1.Controls.Add(Me.ChB_OnlyWin)
        Me.TabPage1.Controls.Add(Me.ChB_NO_internet)
        Me.TabPage1.Controls.Add(Me.ChB_OnlyFREE_OS)
        Me.TabPage1.Location = New System.Drawing.Point(4, 25)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(692, 164)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "General"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Lbl_Paquets
        '
        Me.Lbl_Paquets.AutoSize = True
        Me.Lbl_Paquets.Location = New System.Drawing.Point(328, 94)
        Me.Lbl_Paquets.Name = "Lbl_Paquets"
        Me.Lbl_Paquets.Size = New System.Drawing.Size(318, 16)
        Me.Lbl_Paquets.TabIndex = 15
        Me.Lbl_Paquets.Text = "Gestor de paquets (programes) preferit a GNU/Linux"
        '
        'RB_Linux_Others
        '
        Me.RB_Linux_Others.AutoSize = True
        Me.RB_Linux_Others.Location = New System.Drawing.Point(495, 123)
        Me.RB_Linux_Others.Name = "RB_Linux_Others"
        Me.RB_Linux_Others.Size = New System.Drawing.Size(162, 20)
        Me.RB_Linux_Others.TabIndex = 14
        Me.RB_Linux_Others.Text = "Altres tipus de paquets"
        Me.RB_Linux_Others.UseVisualStyleBackColor = True
        '
        'RB_Linux_RPM
        '
        Me.RB_Linux_RPM.AutoSize = True
        Me.RB_Linux_RPM.Location = New System.Drawing.Point(412, 123)
        Me.RB_Linux_RPM.Name = "RB_Linux_RPM"
        Me.RB_Linux_RPM.Size = New System.Drawing.Size(52, 20)
        Me.RB_Linux_RPM.TabIndex = 13
        Me.RB_Linux_RPM.Text = ".rpm"
        Me.RB_Linux_RPM.UseVisualStyleBackColor = True
        '
        'RB_Linux_DEB
        '
        Me.RB_Linux_DEB.AutoSize = True
        Me.RB_Linux_DEB.Checked = True
        Me.RB_Linux_DEB.Location = New System.Drawing.Point(337, 123)
        Me.RB_Linux_DEB.Name = "RB_Linux_DEB"
        Me.RB_Linux_DEB.Size = New System.Drawing.Size(53, 20)
        Me.RB_Linux_DEB.TabIndex = 12
        Me.RB_Linux_DEB.TabStop = True
        Me.RB_Linux_DEB.Text = ".deb"
        Me.RB_Linux_DEB.UseVisualStyleBackColor = True
        '
        'ChLB_Linux_Type
        '
        Me.ChLB_Linux_Type.FormattingEnabled = True
        Me.ChLB_Linux_Type.Location = New System.Drawing.Point(321, 85)
        Me.ChLB_Linux_Type.Name = "ChLB_Linux_Type"
        Me.ChLB_Linux_Type.Size = New System.Drawing.Size(365, 72)
        Me.ChLB_Linux_Type.TabIndex = 11
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.Label7)
        Me.TabPage2.Controls.Add(Me.NumericUpDownCPU_Hz)
        Me.TabPage2.Controls.Add(Me.ChB_Mhz)
        Me.TabPage2.Controls.Add(Me.ChB_CPU_x64)
        Me.TabPage2.Controls.Add(Me.ChB_CPU_Multi_Core)
        Me.TabPage2.Location = New System.Drawing.Point(4, 25)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(692, 164)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Processador (CPU)"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(219, 98)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(83, 18)
        Me.Label7.TabIndex = 11
        Me.Label7.Text = "GigaHertzs"
        '
        'NumericUpDownCPU_Hz
        '
        Me.NumericUpDownCPU_Hz.DecimalPlaces = 2
        Me.NumericUpDownCPU_Hz.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericUpDownCPU_Hz.Increment = New Decimal(New Integer() {25, 0, 0, 131072})
        Me.NumericUpDownCPU_Hz.Location = New System.Drawing.Point(158, 98)
        Me.NumericUpDownCPU_Hz.Maximum = New Decimal(New Integer() {4, 0, 0, 0})
        Me.NumericUpDownCPU_Hz.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDownCPU_Hz.Name = "NumericUpDownCPU_Hz"
        Me.NumericUpDownCPU_Hz.ReadOnly = True
        Me.NumericUpDownCPU_Hz.Size = New System.Drawing.Size(55, 24)
        Me.NumericUpDownCPU_Hz.TabIndex = 10
        Me.NumericUpDownCPU_Hz.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'ChB_Mhz
        '
        Me.ChB_Mhz.AutoSize = True
        Me.ChB_Mhz.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChB_Mhz.Location = New System.Drawing.Point(6, 72)
        Me.ChB_Mhz.Name = "ChB_Mhz"
        Me.ChB_Mhz.Size = New System.Drawing.Size(395, 22)
        Me.ChB_Mhz.TabIndex = 9
        Me.ChB_Mhz.Text = "Velocitat CPU en Mhz enlloc de Ghz (ordinadors antics)"
        Me.ChB_Mhz.UseVisualStyleBackColor = True
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.Label6)
        Me.TabPage3.Controls.Add(Me.Lbl_RAM)
        Me.TabPage3.Controls.Add(Me.NumericUpDownRAM)
        Me.TabPage3.Controls.Add(Me.ChB_RAM_MB)
        Me.TabPage3.Location = New System.Drawing.Point(4, 25)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(692, 164)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Memòria (RAM)"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(134, 115)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(30, 18)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "GB"
        '
        'Lbl_RAM
        '
        Me.Lbl_RAM.AutoSize = True
        Me.Lbl_RAM.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_RAM.Location = New System.Drawing.Point(12, 92)
        Me.Lbl_RAM.Name = "Lbl_RAM"
        Me.Lbl_RAM.Size = New System.Drawing.Size(333, 18)
        Me.Lbl_RAM.TabIndex = 2
        Me.Lbl_RAM.Text = "Quantitat MÍNIMA de memòria RAM del ordinador"
        '
        'NumericUpDownRAM
        '
        Me.NumericUpDownRAM.DecimalPlaces = 1
        Me.NumericUpDownRAM.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericUpDownRAM.Increment = New Decimal(New Integer() {5, 0, 0, 65536})
        Me.NumericUpDownRAM.Location = New System.Drawing.Point(75, 115)
        Me.NumericUpDownRAM.Maximum = New Decimal(New Integer() {4, 0, 0, 0})
        Me.NumericUpDownRAM.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDownRAM.Name = "NumericUpDownRAM"
        Me.NumericUpDownRAM.ReadOnly = True
        Me.NumericUpDownRAM.Size = New System.Drawing.Size(53, 24)
        Me.NumericUpDownRAM.TabIndex = 1
        Me.NumericUpDownRAM.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'ChB_RAM_MB
        '
        Me.ChB_RAM_MB.AutoSize = True
        Me.ChB_RAM_MB.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChB_RAM_MB.Location = New System.Drawing.Point(15, 13)
        Me.ChB_RAM_MB.Name = "ChB_RAM_MB"
        Me.ChB_RAM_MB.Size = New System.Drawing.Size(458, 22)
        Me.ChB_RAM_MB.TabIndex = 0
        Me.ChB_RAM_MB.Text = "Quantitat de memòria en MB enlloc de GB (per ordinadors antics)"
        Me.ChB_RAM_MB.UseVisualStyleBackColor = True
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.Lbl_GPU)
        Me.TabPage4.Controls.Add(Me.Label9)
        Me.TabPage4.Controls.Add(Me.Lbl_GPU_RAM)
        Me.TabPage4.Controls.Add(Me.NumericUpDown_GPU_MB_RAM)
        Me.TabPage4.Controls.Add(Me.RB_other_GPUs)
        Me.TabPage4.Controls.Add(Me.RB_intel)
        Me.TabPage4.Controls.Add(Me.RB_AMD_ATI)
        Me.TabPage4.Controls.Add(Me.RB_nVidia)
        Me.TabPage4.Controls.Add(Me.ChLB_GPU_Brand)
        Me.TabPage4.Controls.Add(Me.ChB_Embeded_GPU)
        Me.TabPage4.Location = New System.Drawing.Point(4, 25)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(692, 164)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Targeta gràfica (GPU)"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'Lbl_GPU
        '
        Me.Lbl_GPU.AutoSize = True
        Me.Lbl_GPU.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_GPU.Location = New System.Drawing.Point(377, 23)
        Me.Lbl_GPU.Name = "Lbl_GPU"
        Me.Lbl_GPU.Size = New System.Drawing.Size(229, 18)
        Me.Lbl_GPU.TabIndex = 16
        Me.Lbl_GPU.Text = "Marca de la GPU (targeta gràfica)"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(78, 120)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(28, 16)
        Me.Label9.TabIndex = 15
        Me.Label9.Text = "MB"
        '
        'Lbl_GPU_RAM
        '
        Me.Lbl_GPU_RAM.AutoSize = True
        Me.Lbl_GPU_RAM.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_GPU_RAM.Location = New System.Drawing.Point(-3, 92)
        Me.Lbl_GPU_RAM.Name = "Lbl_GPU_RAM"
        Me.Lbl_GPU_RAM.Size = New System.Drawing.Size(302, 18)
        Me.Lbl_GPU_RAM.TabIndex = 14
        Me.Lbl_GPU_RAM.Text = "MB mínim de Memòria GPU (targeta gràfica)"
        '
        'NumericUpDown_GPU_MB_RAM
        '
        Me.NumericUpDown_GPU_MB_RAM.Increment = New Decimal(New Integer() {32, 0, 0, 0})
        Me.NumericUpDown_GPU_MB_RAM.Location = New System.Drawing.Point(22, 118)
        Me.NumericUpDown_GPU_MB_RAM.Maximum = New Decimal(New Integer() {2048, 0, 0, 0})
        Me.NumericUpDown_GPU_MB_RAM.Minimum = New Decimal(New Integer() {32, 0, 0, 0})
        Me.NumericUpDown_GPU_MB_RAM.Name = "NumericUpDown_GPU_MB_RAM"
        Me.NumericUpDown_GPU_MB_RAM.ReadOnly = True
        Me.NumericUpDown_GPU_MB_RAM.Size = New System.Drawing.Size(50, 22)
        Me.NumericUpDown_GPU_MB_RAM.TabIndex = 13
        Me.NumericUpDown_GPU_MB_RAM.Value = New Decimal(New Integer() {256, 0, 0, 0})
        '
        'RB_other_GPUs
        '
        Me.RB_other_GPUs.AutoSize = True
        Me.RB_other_GPUs.Enabled = False
        Me.RB_other_GPUs.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RB_other_GPUs.Location = New System.Drawing.Point(486, 114)
        Me.RB_other_GPUs.Name = "RB_other_GPUs"
        Me.RB_other_GPUs.Size = New System.Drawing.Size(182, 22)
        Me.RB_other_GPUs.TabIndex = 12
        Me.RB_other_GPUs.Text = "Altres marques de GPU"
        Me.RB_other_GPUs.UseVisualStyleBackColor = True
        '
        'RB_intel
        '
        Me.RB_intel.AutoSize = True
        Me.RB_intel.Enabled = False
        Me.RB_intel.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RB_intel.Location = New System.Drawing.Point(360, 114)
        Me.RB_intel.Name = "RB_intel"
        Me.RB_intel.Size = New System.Drawing.Size(89, 22)
        Me.RB_intel.TabIndex = 11
        Me.RB_intel.Text = "GPU intel"
        Me.RB_intel.UseVisualStyleBackColor = True
        '
        'RB_AMD_ATI
        '
        Me.RB_AMD_ATI.AutoSize = True
        Me.RB_AMD_ATI.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RB_AMD_ATI.Location = New System.Drawing.Point(484, 71)
        Me.RB_AMD_ATI.Name = "RB_AMD_ATI"
        Me.RB_AMD_ATI.Size = New System.Drawing.Size(130, 22)
        Me.RB_AMD_ATI.TabIndex = 10
        Me.RB_AMD_ATI.Text = "GPU AMD - ATI"
        Me.RB_AMD_ATI.UseVisualStyleBackColor = True
        '
        'RB_nVidia
        '
        Me.RB_nVidia.AutoSize = True
        Me.RB_nVidia.Checked = True
        Me.RB_nVidia.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RB_nVidia.Location = New System.Drawing.Point(360, 71)
        Me.RB_nVidia.Name = "RB_nVidia"
        Me.RB_nVidia.Size = New System.Drawing.Size(102, 22)
        Me.RB_nVidia.TabIndex = 9
        Me.RB_nVidia.TabStop = True
        Me.RB_nVidia.Text = "GPU nVidia"
        Me.RB_nVidia.UseVisualStyleBackColor = True
        '
        'ChLB_GPU_Brand
        '
        Me.ChLB_GPU_Brand.FormattingEnabled = True
        Me.ChLB_GPU_Brand.Location = New System.Drawing.Point(352, 49)
        Me.ChLB_GPU_Brand.Name = "ChLB_GPU_Brand"
        Me.ChLB_GPU_Brand.Size = New System.Drawing.Size(327, 89)
        Me.ChLB_GPU_Brand.TabIndex = 7
        Me.ChLB_GPU_Brand.Tag = "Marca de la targeta gràfica"
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.Lbl_HDD_GB_info)
        Me.TabPage5.Controls.Add(Me.Label4)
        Me.TabPage5.Controls.Add(Me.Lbl_HDD)
        Me.TabPage5.Controls.Add(Me.NumericUpDownHDD_GB)
        Me.TabPage5.Controls.Add(Me.ChB_SSD)
        Me.TabPage5.Location = New System.Drawing.Point(4, 25)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Size = New System.Drawing.Size(692, 164)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Disc Dur"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'Lbl_HDD_GB_info
        '
        Me.Lbl_HDD_GB_info.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_HDD_GB_info.Location = New System.Drawing.Point(3, 86)
        Me.Lbl_HDD_GB_info.Name = "Lbl_HDD_GB_info"
        Me.Lbl_HDD_GB_info.Size = New System.Drawing.Size(686, 53)
        Me.Lbl_HDD_GB_info.TabIndex = 7
        Me.Lbl_HDD_GB_info.Text = "IMPORTANT! Aquí hem d'indicar quantitat MÍNIMA en GB que li podrem assignar a CAD" &
    "A UN dels sistemes operatius que voldrem posar al disc dur principal (el mes ràp" &
    "id) del nostre PC"
        Me.Lbl_HDD_GB_info.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Lbl_HDD_GB_info.UseCompatibleTextRendering = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(384, 47)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(30, 18)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "GB"
        '
        'Lbl_HDD
        '
        Me.Lbl_HDD.AutoSize = True
        Me.Lbl_HDD.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_HDD.Location = New System.Drawing.Point(287, 22)
        Me.Lbl_HDD.Name = "Lbl_HDD"
        Me.Lbl_HDD.Size = New System.Drawing.Size(304, 18)
        Me.Lbl_HDD.TabIndex = 5
        Me.Lbl_HDD.Text = "MÍNIM de GB disponibles al disc dur principal"
        '
        'NumericUpDownHDD_GB
        '
        Me.NumericUpDownHDD_GB.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericUpDownHDD_GB.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.NumericUpDownHDD_GB.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDownHDD_GB.Location = New System.Drawing.Point(340, 45)
        Me.NumericUpDownHDD_GB.Maximum = New Decimal(New Integer() {60, 0, 0, 0})
        Me.NumericUpDownHDD_GB.Minimum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDownHDD_GB.Name = "NumericUpDownHDD_GB"
        Me.NumericUpDownHDD_GB.ReadOnly = True
        Me.NumericUpDownHDD_GB.Size = New System.Drawing.Size(38, 24)
        Me.NumericUpDownHDD_GB.TabIndex = 4
        Me.NumericUpDownHDD_GB.Value = New Decimal(New Integer() {10, 0, 0, 0})
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(147, 357)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(205, 28)
        Me.Button1.TabIndex = 12
        Me.Button1.Text = "&Calcular Resultat"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(26, 421)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(267, 20)
        Me.Label10.TabIndex = 13
        Me.Label10.Text = "Sistema Operatiu Privatiu recomanat"
        Me.Label10.Visible = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(26, 514)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(254, 20)
        Me.Label11.TabIndex = 14
        Me.Label11.Text = "Sistema Operatiu Lliure recomanat"
        Me.Label11.Visible = False
        '
        'Label12
        '
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Red
        Me.Label12.Location = New System.Drawing.Point(12, 629)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(985, 40)
        Me.Label12.TabIndex = 15
        Me.Label12.Text = "FET ! Per instal·lar arranc dual Windows 10 + Linux cal un MÍNIM de 80 GB lliures" &
    " al disc, assignant primer MÍNIM 60 GB per Windows i finalment, MÍNIM 20 GB per " &
    "Linux"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Label12.Visible = False
        '
        'Bt_reset
        '
        Me.Bt_reset.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bt_reset.Location = New System.Drawing.Point(30, 685)
        Me.Bt_reset.Name = "Bt_reset"
        Me.Bt_reset.Size = New System.Drawing.Size(273, 32)
        Me.Bt_reset.TabIndex = 16
        Me.Bt_reset.Text = "Tornar a valors per &defecte"
        Me.Bt_reset.UseVisualStyleBackColor = True
        '
        'LinkWindows
        '
        Me.LinkWindows.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkWindows.Location = New System.Drawing.Point(12, 441)
        Me.LinkWindows.Name = "LinkWindows"
        Me.LinkWindows.Size = New System.Drawing.Size(686, 61)
        Me.LinkWindows.TabIndex = 19
        Me.LinkWindows.TabStop = True
        Me.LinkWindows.Text = "https://www.microsoft.com/es-es/software-download/windows10"
        Me.LinkWindows.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.LinkWindows.Visible = False
        '
        'LinkLinux
        '
        Me.LinkLinux.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLinux.Location = New System.Drawing.Point(12, 534)
        Me.LinkLinux.Name = "LinkLinux"
        Me.LinkLinux.Size = New System.Drawing.Size(686, 63)
        Me.LinkLinux.TabIndex = 20
        Me.LinkLinux.TabStop = True
        Me.LinkLinux.Text = "https://ubuntu.com/download/desktop/thank-you?version=20.04&architecture=amd64"
        Me.LinkLinux.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.LinkLinux.Visible = False
        '
        'Label13
        '
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(0, 93)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(1007, 18)
        Me.Label13.TabIndex = 21
        Me.Label13.Text = "Tria SO està pensat per poder ajudar al màxim de gent possible, incloent qui nomé" &
    "s te un ordinador de mes de 25 anys d'antiguitat"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.RB_Lang_FRA)
        Me.GroupBox1.Controls.Add(Me.RB_Lang_ESP)
        Me.GroupBox1.Controls.Add(Me.RB_Lang_ENG)
        Me.GroupBox1.Controls.Add(Me.RB_Lang_CAT)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(753, 152)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(205, 182)
        Me.GroupBox1.TabIndex = 24
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Idioma del programa"
        '
        'RB_Lang_FRA
        '
        Me.RB_Lang_FRA.AutoSize = True
        Me.RB_Lang_FRA.Location = New System.Drawing.Point(46, 133)
        Me.RB_Lang_FRA.Name = "RB_Lang_FRA"
        Me.RB_Lang_FRA.Size = New System.Drawing.Size(96, 24)
        Me.RB_Lang_FRA.TabIndex = 3
        Me.RB_Lang_FRA.TabStop = True
        Me.RB_Lang_FRA.Text = "Français"
        Me.RB_Lang_FRA.UseVisualStyleBackColor = True
        '
        'RB_Lang_ESP
        '
        Me.RB_Lang_ESP.AutoSize = True
        Me.RB_Lang_ESP.Location = New System.Drawing.Point(46, 61)
        Me.RB_Lang_ESP.Name = "RB_Lang_ESP"
        Me.RB_Lang_ESP.Size = New System.Drawing.Size(92, 24)
        Me.RB_Lang_ESP.TabIndex = 2
        Me.RB_Lang_ESP.TabStop = True
        Me.RB_Lang_ESP.Text = "Español"
        Me.RB_Lang_ESP.UseVisualStyleBackColor = True
        '
        'RB_Lang_ENG
        '
        Me.RB_Lang_ENG.AutoSize = True
        Me.RB_Lang_ENG.Location = New System.Drawing.Point(46, 100)
        Me.RB_Lang_ENG.Name = "RB_Lang_ENG"
        Me.RB_Lang_ENG.Size = New System.Drawing.Size(86, 24)
        Me.RB_Lang_ENG.TabIndex = 1
        Me.RB_Lang_ENG.TabStop = True
        Me.RB_Lang_ENG.Text = "English"
        Me.RB_Lang_ENG.UseVisualStyleBackColor = True
        '
        'RB_Lang_CAT
        '
        Me.RB_Lang_CAT.AutoSize = True
        Me.RB_Lang_CAT.Checked = True
        Me.RB_Lang_CAT.Location = New System.Drawing.Point(46, 32)
        Me.RB_Lang_CAT.Name = "RB_Lang_CAT"
        Me.RB_Lang_CAT.Size = New System.Drawing.Size(79, 24)
        Me.RB_Lang_CAT.TabIndex = 0
        Me.RB_Lang_CAT.TabStop = True
        Me.RB_Lang_CAT.Text = "Català"
        Me.RB_Lang_CAT.UseVisualStyleBackColor = True
        '
        'Lbl_hack
        '
        Me.Lbl_hack.Enabled = False
        Me.Lbl_hack.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_hack.Location = New System.Drawing.Point(86, 363)
        Me.Lbl_hack.Name = "Lbl_hack"
        Me.Lbl_hack.Size = New System.Drawing.Size(55, 20)
        Me.Lbl_hack.TabIndex = 25
        Me.Lbl_hack.Text = "0"
        Me.Lbl_hack.Visible = False
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(26, 364)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(59, 20)
        Me.Label3.TabIndex = 26
        Me.Label3.Text = "Total : "
        Me.Label3.Visible = False
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Lbl_CPU_Name)
        Me.GroupBox2.Controls.Add(Me.TB_CPU_Name)
        Me.GroupBox2.Controls.Add(Me.TB_PC_HDD)
        Me.GroupBox2.Controls.Add(Me.TB_PC_GPU)
        Me.GroupBox2.Controls.Add(Me.TB_PC_RAM)
        Me.GroupBox2.Controls.Add(Me.TB_PC_CPU)
        Me.GroupBox2.Controls.Add(Me.Lbl_PC_HDD)
        Me.GroupBox2.Controls.Add(Me.Lbl_PC_GPU)
        Me.GroupBox2.Controls.Add(Me.Lbl_PC_RAM)
        Me.GroupBox2.Controls.Add(Me.Lbl_PC_CPU)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(713, 357)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(284, 265)
        Me.GroupBox2.TabIndex = 27
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Valors d'aquest ordinador"
        '
        'Lbl_CPU_Name
        '
        Me.Lbl_CPU_Name.AutoSize = True
        Me.Lbl_CPU_Name.Location = New System.Drawing.Point(68, 35)
        Me.Lbl_CPU_Name.Name = "Lbl_CPU_Name"
        Me.Lbl_CPU_Name.Size = New System.Drawing.Size(111, 20)
        Me.Lbl_CPU_Name.TabIndex = 9
        Me.Lbl_CPU_Name.Text = "CPU Name : "
        '
        'TB_CPU_Name
        '
        Me.TB_CPU_Name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TB_CPU_Name.Location = New System.Drawing.Point(6, 68)
        Me.TB_CPU_Name.Name = "TB_CPU_Name"
        Me.TB_CPU_Name.ReadOnly = True
        Me.TB_CPU_Name.Size = New System.Drawing.Size(272, 22)
        Me.TB_CPU_Name.TabIndex = 8
        '
        'TB_PC_HDD
        '
        Me.TB_PC_HDD.Location = New System.Drawing.Point(179, 233)
        Me.TB_PC_HDD.Name = "TB_PC_HDD"
        Me.TB_PC_HDD.ReadOnly = True
        Me.TB_PC_HDD.Size = New System.Drawing.Size(99, 26)
        Me.TB_PC_HDD.TabIndex = 7
        '
        'TB_PC_GPU
        '
        Me.TB_PC_GPU.Location = New System.Drawing.Point(179, 197)
        Me.TB_PC_GPU.Name = "TB_PC_GPU"
        Me.TB_PC_GPU.ReadOnly = True
        Me.TB_PC_GPU.Size = New System.Drawing.Size(99, 26)
        Me.TB_PC_GPU.TabIndex = 6
        '
        'TB_PC_RAM
        '
        Me.TB_PC_RAM.Location = New System.Drawing.Point(179, 151)
        Me.TB_PC_RAM.Name = "TB_PC_RAM"
        Me.TB_PC_RAM.ReadOnly = True
        Me.TB_PC_RAM.Size = New System.Drawing.Size(99, 26)
        Me.TB_PC_RAM.TabIndex = 5
        '
        'TB_PC_CPU
        '
        Me.TB_PC_CPU.Location = New System.Drawing.Point(179, 110)
        Me.TB_PC_CPU.Name = "TB_PC_CPU"
        Me.TB_PC_CPU.ReadOnly = True
        Me.TB_PC_CPU.Size = New System.Drawing.Size(99, 26)
        Me.TB_PC_CPU.TabIndex = 4
        '
        'Lbl_PC_HDD
        '
        Me.Lbl_PC_HDD.AutoSize = True
        Me.Lbl_PC_HDD.Location = New System.Drawing.Point(84, 236)
        Me.Lbl_PC_HDD.Name = "Lbl_PC_HDD"
        Me.Lbl_PC_HDD.Size = New System.Drawing.Size(89, 20)
        Me.Lbl_PC_HDD.TabIndex = 3
        Me.Lbl_PC_HDD.Text = "GB HDD :"
        '
        'Lbl_PC_GPU
        '
        Me.Lbl_PC_GPU.AutoSize = True
        Me.Lbl_PC_GPU.Location = New System.Drawing.Point(86, 200)
        Me.Lbl_PC_GPU.Name = "Lbl_PC_GPU"
        Me.Lbl_PC_GPU.Size = New System.Drawing.Size(93, 20)
        Me.Lbl_PC_GPU.TabIndex = 2
        Me.Lbl_PC_GPU.Text = "MB GPU : "
        '
        'Lbl_PC_RAM
        '
        Me.Lbl_PC_RAM.AutoSize = True
        Me.Lbl_PC_RAM.Location = New System.Drawing.Point(79, 157)
        Me.Lbl_PC_RAM.Name = "Lbl_PC_RAM"
        Me.Lbl_PC_RAM.Size = New System.Drawing.Size(94, 20)
        Me.Lbl_PC_RAM.TabIndex = 1
        Me.Lbl_PC_RAM.Text = "MB RAM  :"
        '
        'Lbl_PC_CPU
        '
        Me.Lbl_PC_CPU.AutoSize = True
        Me.Lbl_PC_CPU.Location = New System.Drawing.Point(79, 113)
        Me.Lbl_PC_CPU.Name = "Lbl_PC_CPU"
        Me.Lbl_PC_CPU.Size = New System.Drawing.Size(98, 20)
        Me.Lbl_PC_CPU.TabIndex = 0
        Me.Lbl_PC_CPU.Text = "Mhz CPU : "
        '
        'Bt_PC
        '
        Me.Bt_PC.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bt_PC.Location = New System.Drawing.Point(378, 357)
        Me.Bt_PC.Name = "Bt_PC"
        Me.Bt_PC.Size = New System.Drawing.Size(290, 28)
        Me.Bt_PC.TabIndex = 28
        Me.Bt_PC.Text = "Carregar valors d'aquest &PC"
        Me.Bt_PC.UseVisualStyleBackColor = True
        '
        'RTB_dxdiag
        '
        Me.RTB_dxdiag.Location = New System.Drawing.Point(488, 391)
        Me.RTB_dxdiag.Name = "RTB_dxdiag"
        Me.RTB_dxdiag.Size = New System.Drawing.Size(180, 153)
        Me.RTB_dxdiag.TabIndex = 29
        Me.RTB_dxdiag.Text = ""
        Me.RTB_dxdiag.Visible = False
        '
        'Bt_Credits
        '
        Me.Bt_Credits.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bt_Credits.Location = New System.Drawing.Point(873, 685)
        Me.Bt_Credits.Name = "Bt_Credits"
        Me.Bt_Credits.Size = New System.Drawing.Size(123, 32)
        Me.Bt_Credits.TabIndex = 30
        Me.Bt_Credits.Text = "Crèdit&s"
        Me.Bt_Credits.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1008, 729)
        Me.Controls.Add(Me.Bt_Credits)
        Me.Controls.Add(Me.RTB_dxdiag)
        Me.Controls.Add(Me.Bt_PC)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Lbl_hack)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.LinkLinux)
        Me.Controls.Add(Me.LinkWindows)
        Me.Controls.Add(Me.Bt_reset)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximumSize = New System.Drawing.Size(1024, 768)
        Me.MinimumSize = New System.Drawing.Size(1024, 768)
        Me.Name = "Form1"
        Me.Text = "Tria Sistema Operatiu - ver. 1.2"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.NumericUpDownCPU_Hz, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        CType(Me.NumericUpDownRAM, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        CType(Me.NumericUpDown_GPU_MB_RAM, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        CType(Me.NumericUpDownHDD_GB, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents ChB_Laptop As CheckBox
    Friend WithEvents ChB_SSD As CheckBox
    Friend WithEvents ChB_OnlyWin As CheckBox
    Friend WithEvents ChB_OnlyFREE_OS As CheckBox
    Friend WithEvents ChB_Embeded_GPU As CheckBox
    Friend WithEvents ChB_CPU_x64 As CheckBox
    Friend WithEvents ChB_CPU_Multi_Core As CheckBox
    Friend WithEvents ChB_NO_internet As CheckBox
    Friend WithEvents ChB_Wifi As CheckBox
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents TabPage5 As TabPage
    Friend WithEvents ChLB_GPU_Brand As CheckedListBox
    Friend WithEvents RB_AMD_ATI As RadioButton
    Friend WithEvents RB_nVidia As RadioButton
    Friend WithEvents RB_other_GPUs As RadioButton
    Friend WithEvents RB_intel As RadioButton
    Friend WithEvents ChB_RAM_MB As CheckBox
    Friend WithEvents ChB_Mhz As CheckBox
    Friend WithEvents Lbl_HDD As Label
    Friend WithEvents NumericUpDownHDD_GB As NumericUpDown
    Friend WithEvents Label4 As Label
    Friend WithEvents NumericUpDownRAM As NumericUpDown
    Friend WithEvents Label6 As Label
    Friend WithEvents Lbl_RAM As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents NumericUpDownCPU_Hz As NumericUpDown
    Friend WithEvents NumericUpDown_GPU_MB_RAM As NumericUpDown
    Friend WithEvents Label9 As Label
    Friend WithEvents Lbl_GPU_RAM As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Bt_reset As Button
    Friend WithEvents LinkWindows As LinkLabel
    Friend WithEvents LinkLinux As LinkLabel
    Friend WithEvents Label13 As Label
    Friend WithEvents Lbl_GPU As Label
    Friend WithEvents Lbl_HDD_GB_info As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents RB_Lang_CAT As RadioButton
    Friend WithEvents RB_Lang_ENG As RadioButton
    Friend WithEvents RB_Lang_FRA As RadioButton
    Friend WithEvents RB_Lang_ESP As RadioButton
    Friend WithEvents Lbl_hack As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Bt_PC As Button
    Friend WithEvents TB_PC_HDD As TextBox
    Friend WithEvents TB_PC_GPU As TextBox
    Friend WithEvents TB_PC_RAM As TextBox
    Friend WithEvents TB_PC_CPU As TextBox
    Friend WithEvents Lbl_PC_HDD As Label
    Friend WithEvents Lbl_PC_GPU As Label
    Friend WithEvents Lbl_PC_RAM As Label
    Friend WithEvents Lbl_PC_CPU As Label
    Friend WithEvents Lbl_CPU_Name As Label
    Friend WithEvents TB_CPU_Name As TextBox
    Friend WithEvents RTB_dxdiag As RichTextBox
    Friend WithEvents RB_Linux_Others As RadioButton
    Friend WithEvents RB_Linux_RPM As RadioButton
    Friend WithEvents RB_Linux_DEB As RadioButton
    Friend WithEvents ChLB_Linux_Type As CheckedListBox
    Friend WithEvents Lbl_Paquets As Label
    Friend WithEvents Bt_Credits As Button
End Class
